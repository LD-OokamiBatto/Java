package com.wb.consumo;

import java.util.List;

import com.wb.modelo.Servico;

public abstract class ServUsados {
	public abstract List<Servico> listaServUsados();
}
