package com.wb.app;

public abstract class ToDo {
	public abstract void executar();
}
