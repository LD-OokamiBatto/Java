package com.wb.cadastros;

public abstract class Add {
	public abstract void cadastrar();
}
