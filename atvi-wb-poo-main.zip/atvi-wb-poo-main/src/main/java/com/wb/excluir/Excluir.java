package com.wb.excluir;

public abstract class Excluir {
	public abstract void excluir();
}
