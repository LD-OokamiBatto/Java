package com.wb.atualizacao;

public abstract class Att {
	public abstract void atualizar();
}
