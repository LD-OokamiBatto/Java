package com.wb.listas;

public abstract class Lista {
	public abstract void lista();
}